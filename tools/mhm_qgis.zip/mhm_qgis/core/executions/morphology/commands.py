"""QGIS-free commands used by morphology task schedulers."""
from __future__ import annotations

import contextlib
import json
import os
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory

from ....dependency_bootstrap import python_environment, python_executable
from ....externals.mhm_tools_handler import prepare_lai_file
from ...handlers.raster.tasks import (
    dem_derivative_files,
    hydrology_files,
)
from ...handlers.state.cache import (
    cached_payload,
    fingerprint,
    load_state,
    outputs_newer_than_inputs,
    outputs_present,
    store_payload,
)
from ...handlers.store.paths import morph_staging_folder, temp_morphology_folder
from ...morphology.layers.advanced_l0 import publish_model_inputs
from ...morphology.layers.categorical import copy_ready, saved_outputs


def dem_derivatives(task, options):
    """Prepare the DEM derivatives in a disposable native process."""

    def compute(prepared, staging, _log, factor=1):
        result = native_worker(
            task,
            {
                "kind": "dem-derivatives",
                "input_file": str(prepared),
                "output_folder": str(staging),
                "factor": factor,
            },
            Path(staging).parent,
        )
        return Path(result["output"])

    return dem_derivative_files(task=task, compute=compute, **options)


def hydrology(task, options):
    return hydrology_files(task=task, **options)


def gauge_position(task, options):
    result = native_worker(
        task,
        {"kind": "gauge-position", **options},
        Path(options["output_path"]).parent,
    )
    return result["output"]


def lai(task, options, messages):
    return prepare_lai_file(
        options["source_path"],
        options["filled_dem"],
        options["output_path"],
        output_temporal_resolution=options["target_timestep"],
        source_variable=options.get("source_variable"),
        input_crs=options.get("source_crs") or None,
        dem_crs=options.get("dem_crs") or None,
        resampling=options.get("method") or "bilinear",
        l0_header=options.get("l0_header"),
        task=task,
        log=messages.append,
    )


def lookup(task, job):
    result = native_worker(
        task,
        {"mode": "lookup", "kind": job["kind"], "job": job},
        job["geometry"],
    )
    return {
        "kind": result["kind"],
        "output": result["output"],
        "definition": result.get("definition", ""),
        "metadata": result.get("metadata", ""),
    }


def advanced(task, job):
    payload = dict(job)
    payload["value"] = job["value"].as_dict()
    result = native_worker(task, payload, temp_morphology_folder(job["setup_folder"]))
    return {"kind": result["kind"], "outputs": tuple(result["outputs"])}


def ready(task, job):
    """Place and publish one mHM-ready categorical raster, or a stack of its `layers` (periods or
    horizons; categorical soil horizons map through `lookup` first)."""
    source, variable, source_crs = job["input_path"], job.get("variable", ""), job.get("source_crs", "")
    definition = job.get("classdefinition_path", "")
    layers = job.get("layers")
    if layers:
        if job.get("lookup"):
            from ...morphology.layers.categorical import lookup_soil_layers

            lookup = job["lookup"]
            layers, definition = lookup_soil_layers(
                layers, lookup["lookup_table"], lookup["mapping_field"], lookup["class_field"],
                Path(morph_staging_folder(job["setup_folder"])) / "_soil_horizons",
                dem_file=job.get("filled_dem"), dem_crs=job["target_crs"], source_crs=source_crs)
        from ...morphology.layers.categorical import STACKS, stack_ready_layers

        source = stack_ready_layers(job["setup_folder"], job["kind"], layers, source_crs=source_crs,
                                    target_crs=job["target_crs"], target_header=job["target_header"], task=task)
        variable, source_crs = STACKS[job["kind"]][1], ""  # already on L0
    staged = copy_ready(
        job["setup_folder"],
        job["kind"],
        source,
        definition_source=definition,
        variable=variable,
        source_crs=source_crs,
        target_crs=job["target_crs"],
        target_header=job["target_header"],
        task=task,
    )
    published = (
        publish_model_inputs(job["setup_folder"], job["target_header"])
        if job.get("publish")
        else ()
    )
    return {
        "kind": job["kind"],
        "outputs": tuple(map(str, staged)),
        "published": tuple(map(str, published)),
    }


def stage_digest(inputs, config):
    return fingerprint(inputs, config)


def reusable_stage(setup_folder, stage, digest, *, inputs=(), outputs=()):
    """Return reusable output metadata, adopting safe existing outputs."""
    if not setup_folder:
        return None
    payload = cached_payload(setup_folder, "stages", stage, digest)
    if outputs_present(payload):
        return payload
    if stage in load_state(setup_folder).get("stages", {}):
        return None  # A changed configuration cannot adopt its own stale outputs.
    candidates = [str(path) for path in outputs if path]
    if (
        not candidates
        or not all(Path(path).is_file() for path in candidates)
        or not outputs_newer_than_inputs(inputs, candidates)
    ):
        return None
    record_stage(setup_folder, stage, digest, candidates)
    return {"outputs": candidates, "adopted": True}


def record_stage(setup_folder, stage, digest, outputs):
    paths = [str(path) for path in outputs if path and Path(path).is_file()]
    if setup_folder and paths:
        store_payload(
            setup_folder,
            "stages",
            stage,
            digest,
            {"outputs": paths},
        )


def categorical_outputs(setup_folder, kind):
    return saved_outputs(setup_folder, kind)


def native_worker(task, payload, working_folder):
    """Run one native job without risking the long-lived QGIS process."""
    if task is not None and task.isCanceled():
        raise RuntimeError("Task cancelled.")
    if task is not None:
        task.setProgress(5)
    with TemporaryDirectory(
        prefix="mhm_qgis_native_", dir=str(working_folder)
    ) as temporary_name:
        temporary = Path(temporary_name)
        job_file = temporary / "job.json"
        result_file = temporary / "result.json"
        progress_file = temporary / "progress.txt"  # the child writes 0-100 here
        job_file.write_text(json.dumps({**payload, "progress": str(progress_file)}), encoding="utf-8")
        environment = python_environment()  # it imports what QGIS imports, the plugin's packages included
        package_parent = str(Path(__file__).resolve().parents[4])
        environment["PYTHONPATH"] = os.pathsep.join((package_parent, environment["PYTHONPATH"]))
        log_file = temporary / "worker.log"
        with log_file.open("w", encoding="utf-8") as log_stream:
            process = subprocess.Popen(  # nosec B603: this Python running the plugin's own worker on its own files
                [
                    python_executable(),
                    "-m",
                    "mhm_qgis.core.native_worker",
                    str(job_file),
                    str(result_file),
                ],
                stdout=log_stream,
                stderr=subprocess.STDOUT,
                text=True,
                env=environment,
            )
            while process.poll() is None:
                if task is not None and task.isCanceled():
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise RuntimeError("Task cancelled.")
                try:
                    process.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    if task is not None and progress_file.is_file():
                        with contextlib.suppress(OSError, ValueError):
                            task.setProgress(max(5, min(99, int(progress_file.read_text(encoding="ascii")))))
                    continue
        log = log_file.read_text(encoding="utf-8", errors="replace").strip()
        if not result_file.is_file():
            raise RuntimeError(
                f"Native raster worker failed: {log or f'exit status {process.returncode}'}"
            )
        response = json.loads(result_file.read_text(encoding="utf-8"))
        if process.returncode or response.get("error"):
            raise RuntimeError(
                response.get("traceback") or response.get("error") or log
            )
        result = response["result"]
    if task is not None:
        task.setProgress(100)
    return result


__all__ = [
    "advanced",
    "categorical_outputs",
    "dem_derivatives",
    "gauge_position",
    "hydrology",
    "lai",
    "lookup",
    "native_worker",
    "ready",
    "record_stage",
    "reusable_stage",
    "stage_digest",
]
