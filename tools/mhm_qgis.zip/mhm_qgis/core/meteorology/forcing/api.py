"""Independent forcing variables, streamed at a selected output cadence."""
from __future__ import annotations

import itertools
import math
import os
import tempfile
from dataclasses import dataclass, replace
from functools import lru_cache
from pathlib import Path

from ...grid import (
    Extent,
    TargetGrid,
    assert_header_file_matches,
    assert_matches_header,
    axes_match_header,
    axis_resolution,
)
from ...grid import crs_equal as _same_crs
from ...grid import (
    header_center_arrays,
    mesh_resolution,
    nearest_curvilinear,
    nearest_rectilinear,
    shift_onto_header,
    slice_and_pad,
)
from ...handlers.store.layout import meteo_file
from .io import write_header, write_netcdf
from .temporal import (
    CADENCES,
    VARIABLE_LABELS,
    VARIABLES,
    about_variable,
    complete_window,
    convert_units,
    cycle_starts,
    deaccumulate_values,
    interval_bounds,
    normalize_unit,
    output_periods,
    period_bounds,
    time_index,
    validate_spec,
)
from .types import (
    AUTO,
    MeteoFolderSpec,
    MeteoForcingResult,
    SpatialMetadata,
)


@dataclass(frozen=True)
class _SpatialSignature:
    metadata: SpatialMetadata
    x_values: object
    y_values: object


def _check_cancel(cancelled):
    if cancelled is not None and cancelled():
        raise RuntimeError("Meteorology task cancelled.")


def inspect_meteo_folder(folder, kind=None, source=AUTO, crs_fallback=None,
                         *, cancelled=None, **options):
    """Inspect metadata only; no forcing arrays are read or prepared."""
    import numpy as np
    spec = (folder if isinstance(folder, MeteoFolderSpec) else
            MeteoFolderSpec(kind, folder, source, crs_fallback, **options)).normalized()
    validate_spec(spec)
    signatures, records = [], []
    for path in _files_for_spec(spec):
        _check_cancel(cancelled)
        signatures.append(_inspect_file(path, spec))
        with _open_dataset(path) as ds:
            variable = _find_variable(ds, spec)
            units = ds[variable].attrs.get("units")
            if units and normalize_unit(units) != normalize_unit(spec.unit):
                raise ValueError(f"{path.name}: metadata unit {units!r} differs from selected {spec.unit!r}.")
            time_name = "time" if "time" in ds[variable].dims else "valid_time"
            bounds = interval_bounds(ds, time_name, spec, variable)
            records.append((path, ds[time_name].values.copy(), bounds))
    _validate_spatial_signatures(signatures)
    records.sort(key=lambda item: item[1][0])
    times = np.concatenate([item[1] for item in records])
    bounds = np.concatenate([item[2] for item in records])
    time_index(times, spec.temporal_resolution, continuous=False)
    if (bounds[:-1, 1] != bounds[1:, 0]).any():
        raise ValueError("Meteorology files contain overlapping or missing intervals.")
    if spec.cumulative:  # e.g. ERA5-Land's first 00:00 stamp: the previous day's total, no cycle of its own
        import pandas as pd

        opens = cycle_starts(pd.DatetimeIndex(bounds[:, 0]), spec.cumulative_resolution, spec.cumulative_reset)
        if not opens.any():
            raise ValueError("Cumulative data hold no start of an accumulation cycle: check the reset.")
        bounds = bounds[int(np.argmax(opens)):]
    start, _, last = complete_window(
        bounds, spec.temporal_resolution, spec.output_temporal_resolution)
    return replace(signatures[0].metadata, files=tuple(item[0] for item in records),
                   start_time=str(start), end_time=str(last))


def inspect_meteo_inputs(inputs):
    """Inspect one input per output variable."""
    specs = [spec.normalized() for spec in inputs]
    if len({spec.kind for spec in specs}) != len(specs):
        raise ValueError("Configure each meteorology variable only once.")
    inspected = {}
    for spec in specs:
        with about_variable(spec.kind):
            inspected[spec.kind] = inspect_meteo_folder(spec)
    return inspected


def process_meteo_inputs(inputs, output_root, target_grid, *, flat_layout=False,
                         log=None, inspections=None, progress=None, cancelled=None):
    """Stream inputs onto L2, optionally aggregating to a coarser cadence."""
    target_grid.validate()
    specs = [spec.normalized() for spec in inputs]
    if not specs or len({spec.kind for spec in specs}) != len(specs):
        raise ValueError("Configure one input per meteorology variable.")
    inspected = inspections if inspections is not None else inspect_meteo_inputs(specs)
    import numpy as np
    windows = {
        spec.kind: (
            np.datetime64(inspected[spec.kind].start_time),
            period_bounds(output_periods(
                np.datetime64(inspected[spec.kind].end_time),
                spec.output_temporal_resolution))[1],
        ) for spec in specs
    }
    common = windows.get("pre")
    if common:
        for kind, (start, end) in windows.items():
            if start > common[0] or end < common[1]:
                raise ValueError(f"{VARIABLE_LABELS.get(kind, kind)}: the complete data do not cover "
                                 "the precipitation period.")
    root = Path(output_root)
    root.mkdir(parents=True, exist_ok=True)
    outputs, headers, files_used = {}, {}, {}
    tick = _file_ticker(specs, inspected, progress, log)
    with tempfile.TemporaryDirectory(prefix=".mhm_qgis-meteo-", dir=root) as temporary:
        stage = Path(temporary)
        for spec in specs:
            with about_variable(spec.kind):
                _check_cancel(cancelled)
                validate_spec(spec)
                metadata = inspected[spec.kind]
                _validate_target_coverage(metadata, target_grid)
                output = stage / meteo_file(spec.kind, flat_layout)
                count = 0
                handle = None
                try:
                    for block in _prepared_blocks(
                        spec, metadata, target_grid, window=common or windows[spec.kind],
                        log=log, on_file=tick, cancelled=cancelled,
                    ):
                        _check_cancel(cancelled)
                        assert_matches_header(block, spec.kind, target_grid.header)
                        handle = _write_time_block(block.rename({spec.kind: output.stem}), output.stem, output,
                                                   count, handle)
                        count += block.sizes["time"]
                        block.close()
                finally:
                    if handle is not None:
                        handle.close()
                if not count:
                    raise ValueError("No time steps to write.")
            outputs[spec.kind] = output
            files_used[spec.kind] = len(metadata.files)
            if not flat_layout:
                header = output.with_name("header.txt")
                write_header(None, spec.kind, header, header=dict(target_grid.header))
                assert_header_file_matches(header, target_grid.header)
                headers[spec.kind] = header
            if log:
                log(f"{spec.kind}: prepared {count} {spec.output_temporal_resolution.lower()} intervals.")
        _check_cancel(cancelled)
        return _publish_meteo_result(MeteoForcingResult(outputs, headers, files_used),
                                     root, flat_layout=flat_layout)


def _file_ticker(specs, inspected, progress, log):
    """Report percentage and a log line as input files are consumed.

    Without this the run is silent and pinned at 0% from the first line until a
    whole variable finishes, which on a multi-decade record is most of an hour.
    """
    total = sum(len(inspected[spec.kind].files) for spec in specs) or 1
    state = {"done": 0}

    def tick(kind):
        state["done"] += 1
        if progress is not None:
            progress(int(100 * state["done"] / total))
        if log and (state["done"] % 25 == 0 or state["done"] == total):
            log(f"{kind}: {state['done']} of {total} input files processed.")

    return tick


# Aggregated intervals are stacked before they are aligned and written: doing
# that per day meant one resample, one Dataset build and one file append each,
# which is what made a multi-decade hourly record take hours. The batch is
# capped again per grid so a large L2 grid cannot buffer gigabytes.
INTERVAL_BATCH = 256


def _prepared_blocks(spec, metadata, target, *, window=None, log=None,
                     on_file=None, cancelled=None):
    """Aggregate intervals, then convert and align them in batches."""
    import numpy as np
    import xarray as xr
    previous = None
    pending = None
    last_path = None
    finished = []
    for path in metadata.files:
        _check_cancel(cancelled)
        last_path = path
        with _open_dataset(path) as ds:
            variable = _find_variable(ds, spec)
            raw = ds[variable]
            time_name = "time" if "time" in raw.dims else "valid_time"
            bounds = interval_bounds(ds, time_name, spec, variable)
            y_dim, x_dim = _spatial_dims(raw)
            for dim in tuple(raw.dims):
                if dim not in {time_name, y_dim, x_dim}:
                    raw = raw.isel({dim: 0}, drop=True)
            raw = raw.rename({time_name: "time"}) if time_name != "time" else raw
            raw = raw.transpose("time", y_dim, x_dim)
            cells = max(raw.sizes[y_dim] * raw.sizes[x_dim],
                        int(target.header["nrows"]) * int(target.header["ncols"]))
            block_size = min(1024, max(1, 64 * 1024 * 1024 // (8 * cells)))
            # Buffered intervals are held in memory, so bound them the same way.
            batch = min(INTERVAL_BATCH, max(1, 64 * 1024 * 1024 // (8 * cells)))
            for start in range(0, raw.sizes["time"], block_size):
                _check_cancel(cancelled)
                chunk = raw.isel(time=slice(start, start + block_size)).load()
                chunk_bounds = bounds[start:start + block_size]
                values, previous = deaccumulate_values(
                    chunk.values, chunk_bounds, spec, previous)
                if window is not None:
                    selected = ((chunk_bounds[:, 0] >= window[0])
                                & (chunk_bounds[:, 1] <= window[1]))
                    if not selected.any():
                        continue
                    chunk = chunk.isel(time=np.flatnonzero(selected))
                    chunk_bounds = chunk_bounds[selected]
                    values = values[selected]
                if spec.output_temporal_resolution == spec.temporal_resolution:
                    chunk = chunk.assign_coords(time=chunk_bounds[:, 0])  # v5.13 reads only `time`
                    converted = convert_units(values, chunk_bounds, spec, variable)
                    yield _prepared_dataset(
                        chunk.copy(data=converted), chunk_bounds, ds, spec,
                        target, np, xr)
                    continue
                periods = output_periods(
                    chunk_bounds[:, 0], spec.output_temporal_resolution)
                edges = _group_edges(periods, np)
                group_value, group_count = _reduce_groups(
                    values, edges, spec.aggregation, np)
                for number in range(len(edges) - 1):
                    first, stop = int(edges[number]), int(edges[number + 1])
                    expected = periods[first]
                    if pending is not None and pending["expected"] != expected:
                        finished.append(_finish_interval(pending, spec, np, log))
                        pending = None
                        if len(finished) >= batch:
                            yield _stacked_dataset(finished, ds, spec, target, np, xr)
                            finished = []
                    if pending is None:
                        pending = {
                            "expected": expected,
                            "start": chunk_bounds[first, 0],
                            "end": chunk_bounds[stop - 1, 1],
                            "value": group_value[number],
                            "count": group_count[number],
                            "template": chunk.isel(time=slice(first, first + 1)),
                            "source": variable,
                            "input_seconds": float(
                                (chunk_bounds[first, 1] - chunk_bounds[first, 0])
                                / np.timedelta64(1, "s")),
                        }
                    else:
                        _merge_group(
                            pending, group_value[number], group_count[number],
                            spec.aggregation, np)
                        pending["end"] = chunk_bounds[stop - 1, 1]
        if on_file is not None:
            on_file(spec.kind)
    if pending is not None:
        finished.append(_finish_interval(pending, spec, np, log))
    if finished and last_path is not None:
        with _open_dataset(last_path) as ds:
            yield _stacked_dataset(finished, ds, spec, target, np, xr)


def _finish_interval(pending, spec, np, log):
    """Return one aggregated interval as (single-step template, bounds)."""
    actual = np.asarray([[pending["start"], pending["end"]]], dtype="datetime64[ns]")
    if tuple(actual[0]) != period_bounds(pending["expected"]) and log:
        log(
            f"WARNING: {spec.kind}: partial {spec.output_temporal_resolution.lower()} "
            f"interval {actual[0, 0]} to {actual[0, 1]}; aggregating available values."
        )
    values = _aggregate_result(pending, spec.aggregation, np)[None, ...]
    values = convert_units(
        values, actual, spec, pending["source"],
        input_seconds=pending["input_seconds"])
    return pending["template"].assign_coords(time=[actual[0, 0]]).copy(data=values), actual


def _stacked_dataset(finished, ds, spec, target, np, xr):
    """Align and convert one batch of finished intervals in a single pass."""
    chunk = (finished[0][0] if len(finished) == 1
             else xr.concat([template for template, _ in finished], dim="time"))
    bounds = np.concatenate([interval for _, interval in finished])
    return _prepared_dataset(chunk, bounds, ds, spec, target, np, xr)


def _group_edges(periods, np):
    """Return the index boundaries of each run of equal interval keys."""
    changed = np.flatnonzero(periods[1:] != periods[:-1]) + 1
    return np.concatenate(([0], changed, [len(periods)]))


def _reduce_groups(values, edges, method, np):
    """Reduce every interval in one chunk along time, without a Python loop.

    Uniform groups -- the usual hourly-to-daily case -- reduce as a single
    reshaped call. Monthly and yearly intervals have unequal lengths, so those
    fall back to one vectorised reduction per interval: still tens of
    iterations per file instead of one per timestep.
    """
    lengths = np.diff(edges)
    if len(lengths) > 1 and bool(np.all(lengths == lengths[0])):
        block = values.reshape(len(lengths), int(lengths[0]), *values.shape[1:])
        return _reduce_axis(block, 1, method, np)
    reduced = [_reduce_axis(values[first:stop], 0, method, np)
               for first, stop in itertools.pairwise(edges)]
    return (np.stack([value for value, _ in reduced]),
            np.stack([count for _, count in reduced]))


def _reduce_axis(values, axis, method, np):
    """Return the (partial aggregate, valid count) of one axis."""
    if method in {"Average", "Sum"}:
        finite = np.isfinite(values)
        return (np.add.reduce(np.where(finite, values, 0.0), axis=axis),
                finite.sum(axis=axis, dtype="int32"))
    # fmin/fmax already ignore NaN, so no masked copy of the block is needed;
    # the result is NaN exactly where an interval had no valid sample.
    reducer = np.fmin if method == "Minimum" else np.fmax
    value = reducer.reduce(values, axis=axis)
    return value, np.isfinite(value).astype("int32")


def _merge_group(pending, value, count, method, np):
    """Fold one reduced interval into a partial one carried across a boundary."""
    if method in {"Average", "Sum"}:
        pending["value"] = pending["value"] + value
        pending["count"] = pending["count"] + count
    else:
        reducer = np.fmin if method == "Minimum" else np.fmax
        pending["value"] = reducer(pending["value"], value)
        pending["count"] = np.isfinite(pending["value"]).astype("int32")


def _aggregate_result(pending, method, np):
    if method == "Average":
        return np.divide(
            pending["value"], pending["count"],
            out=np.full_like(pending["value"], np.nan),
            where=pending["count"] > 0)
    return np.where(pending["count"] > 0, pending["value"], np.nan)


def _prepared_dataset(chunk, bounds, ds, spec, target, np, xr):
    chunk = _resample_ready(chunk, ds, spec.crs, target, np, xr).load()
    chunk.name = spec.kind
    chunk.attrs = {
        "units": VARIABLES[spec.kind][1],
        "long_name": spec.kind,
        "input_cadence": spec.temporal_resolution,
        "output_cadence": spec.output_temporal_resolution,
    }
    output = chunk.to_dataset()
    output["time_bnds"] = (("time", "bnds"), bounds)
    output["time"].attrs = {
        "standard_name": "time", "axis": "T", "bounds": "time_bnds"}
    output["lat"].attrs = {"standard_name": "latitude", "units": "degrees_north"}
    output["lon"].attrs = {"standard_name": "longitude", "units": "degrees_east"}
    output.attrs = {"Conventions": "CF-1.8", "history": "Prepared by mhm_qgis"}
    return _attach_target_coordinates(output, spec.kind, target)


def _write_time_block(ds, variable, path, offset, handle=None):
    """Create once, then append through one open handle, and return it.

    Reopening the file per block cost milliseconds each and grew with the
    unlimited time dimension, which dominated a multi-decade record.
    """
    import numpy as np
    import pandas as pd
    from netCDF4 import Dataset, date2num

    if not offset:
        write_netcdf(ds, variable, path, unlimited_dims=("time",))
        handle = Dataset(path, "a")
        for name in ("units", "calendar"):
            handle["time_bnds"].setncattr(name, handle["time"].getncattr(name))
        return handle
    stop = offset + ds.sizes["time"]
    handle[variable][offset:stop] = np.ma.masked_invalid(ds[variable].values)
    for name in ("time", "time_bnds"):
        target = handle[name]
        values = ds[name].values
        dates = pd.DatetimeIndex(values.reshape(-1)).to_pydatetime()
        target[offset:stop] = np.asarray(date2num(dates, getattr(target, "units", handle["time"].units), getattr(target, "calendar", handle["time"].calendar))).reshape(values.shape)
    return handle


def _publish_meteo_result(
        staged: MeteoForcingResult,
        output_root: Path,
        *,
        flat_layout: bool = False) -> MeteoForcingResult:
    """Publish a complete staged result and roll back replacement failures."""
    first_output = next(iter(staged.outputs.values()))
    staging_root = first_output.parent if flat_layout else first_output.parents[1]
    backup_root = staging_root / "backups"
    managed_variables = tuple(staged.outputs)
    backups: list[tuple[Path, Path]] = []
    published: list[Path] = []

    try:
        for variable in managed_variables:
            final = output_root / meteo_file(variable, flat_layout)
            finals = (final,) if flat_layout else (final, final.with_name("header.txt"))
            for final in finals:
                if not final.exists():
                    continue
                backup = backup_root / final.relative_to(output_root)
                backup.parent.mkdir(parents=True, exist_ok=True)
                os.replace(final, backup)
                backups.append((backup, final))

        final_outputs = {}
        final_headers = {}
        for variable, staged_output in staged.outputs.items():
            final_output = output_root / meteo_file(variable, flat_layout)
            final_output.parent.mkdir(parents=True, exist_ok=True)
            final_header = None if flat_layout else final_output.with_name("header.txt")
            os.replace(staged_output, final_output)
            published.append(final_output)
            if final_header is not None and final_header not in published:  # strd shares ssrd's folder
                os.replace(staged.headers[variable], final_header)
                published.append(final_header)
                final_headers[variable] = final_header
            final_outputs[variable] = final_output

        return MeteoForcingResult(
            final_outputs,
            final_headers,
            dict(staged.files_used),
        )
    except Exception:
        for path in published:
            if path.exists():
                path.unlink()
        for backup, final in reversed(backups):
            if backup.exists():
                final.parent.mkdir(parents=True, exist_ok=True)
                os.replace(backup, final)
        raise


def _files_for_spec(spec: MeteoFolderSpec) -> list[Path]:
    folder = Path(spec.folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Meteorology folder does not exist: {folder}")
    pattern = spec.pattern.strip()
    if not pattern or Path(pattern).is_absolute() or ".." in Path(pattern).parts:
        raise ValueError("Enter a relative NetCDF glob within the selected folder.")
    files = sorted(path for path in folder.glob(pattern)
                   if path.is_file() and path.suffix.lower() == ".nc")
    if not files:
        raise ValueError(f"No NetCDF files match {pattern!r} in {folder}.")
    return files


def _open_dataset(path: Path):
    import xarray as xr

    first_error = None  # netCDF4's names the file's problem; the auto engine's only lists backends
    for engine in ("netcdf4", "h5netcdf", "scipy", None):
        try:
            kwargs = {} if engine is None else {"engine": engine}
            return xr.open_dataset(
                path, decode_times=True, mask_and_scale=True, **kwargs)
        except Exception as exc:
            first_error = first_error or exc
    raise RuntimeError(f"Could not open {path} ({first_error}): check that it is a complete NetCDF file.")


def file_defaults(spec):
    """The first matching file's time-dependent `variables`, and the `variable`, time step, unit and
    CRS it declares; undeclared ones are left out (no `variable` when its name is not known)."""
    path = _files_for_spec(spec)[0]
    found = {"file": path.name}
    with _open_dataset(path) as ds:
        bounds = {item.attrs.get("bounds") for item in ds.variables.values()}  # e.g. time_bnds
        found["variables"] = [name for name, data in ds.data_vars.items()
                              if {"time", "valid_time"} & set(data.dims) and name not in bounds]
        try:
            variable = _find_variable(ds, spec if spec.variable in found["variables"] else replace(spec, variable=""))
        except ValueError:
            return found
        found["variable"] = variable
        if (unit := normalize_unit(ds[variable].attrs.get("units", ""))) in VARIABLES[spec.kind][2]:
            found["unit"] = unit
        times = ds["time" if "time" in ds[variable].dims else "valid_time"].values
    for cadence in CADENCES if len(times) > 1 else ():  # one timestamp passes any cadence
        try:
            time_index(times, cadence)
        except ValueError:
            continue
        found["temporal_resolution"] = cadence
        break
    if crs := _inspect_file(path, replace(spec, crs=None), variable).metadata.crs:
        found["crs"] = crs
    return found


def netcdf_grid(path, variable, crs=None):
    """A NetCDF variable's grid as the forcing reads it, from its axes only (GDAL builds a band per
    time step: minutes for a long series): cell-edge bounds (xmin, xmax, ymin, ymax), columns, rows
    and the CRS the file declares (else `crs`)."""
    try:
        metadata = _inspect_file(Path(path), MeteoFolderSpec("pre", Path(path).parent, crs=crs), variable).metadata
    except (KeyError, ValueError) as error:
        raise ValueError(f"{Path(path).name}: no grid information (lower-left corner and cell size): {error}. "
                         "Select another file.") from error
    bounds = Extent.from_centres(metadata.bounds, metadata.x_resolution, metadata.y_resolution).bounds
    return bounds, metadata.shape[1], metadata.shape[0], metadata.crs



def netcdf_first_slice(path, variable):
    """A variable's first time step as a 2-D array, north row first (for display only)."""
    import numpy as np

    with _open_dataset(Path(path)) as ds:
        da = ds[variable]
        y_dim, x_dim = _spatial_dims(da)
        da = da.isel({dim: 0 for dim in da.dims if dim not in (y_dim, x_dim)}).transpose(y_dim, x_dim)
        y = _axis_values(ds, y_dim, "y")[1]
        values = np.asarray(da.values, dtype="float32")
    return values[::-1] if y is not None and len(y) > 1 and float(y[0]) < float(y[-1]) else values


def _inspect_file(
        path: Path,
        spec: MeteoFolderSpec,
        variable: str | None = None) -> _SpatialSignature:
    import numpy as np

    with _open_dataset(path) as ds:
        variable = variable or _find_variable(ds, spec)
        da = ds[variable]
        y_dim, x_dim = _spatial_dims(da)
        x_name, x_values = _axis_values(ds, x_dim, "x")
        y_name, y_values = _axis_values(ds, y_dim, "y")

        if x_values is None or y_values is None:
            lon_name, lon = _geographic_coordinate(ds, "lon", (y_dim, x_dim))
            lat_name, lat = _geographic_coordinate(ds, "lat", (y_dim, x_dim))
            if lon is None or lat is None:
                raise ValueError(
                    f"{path.name}: could not identify spatial coordinates.")
            x_name, y_name = lon_name, lat_name
            x_values, y_values = lon, lat

        crs = _dataset_crs(ds, da, x_name, y_name) or spec.crs
        x_values = np.asarray(x_values, dtype="float64")
        y_values = np.asarray(y_values, dtype="float64")
        if x_values.ndim == 1 and y_values.ndim == 1:
            x_values, y_values = _centre_axes(ds, (y_dim, x_dim), x_name, y_name, x_values, y_values, crs)
            dx = axis_resolution(x_values, f"{path.name}: coordinate {x_name}")
            dy = axis_resolution(y_values, f"{path.name}: coordinate {y_name}")
            bounds = (
                float(np.nanmin(x_values)), float(np.nanmax(x_values)),
                float(np.nanmin(y_values)), float(np.nanmax(y_values)))
            shape = (len(y_values), len(x_values))
        elif x_values.shape == y_values.shape == (
                da.sizes[y_dim], da.sizes[x_dim]):
            dx = mesh_resolution(
                x_values, axis=1, label=f"{path.name}: coordinate {x_name}"
            )
            dy = mesh_resolution(
                y_values, axis=0, label=f"{path.name}: coordinate {y_name}"
            )
            bounds = (
                float(np.nanmin(x_values)), float(np.nanmax(x_values)),
                float(np.nanmin(y_values)), float(np.nanmax(y_values)))
            shape = x_values.shape
        else:
            raise ValueError(f"{path.name}: spatial coordinates are not a 2-D grid.")

        unit = _coordinate_unit(ds, x_name, crs)
        metadata = SpatialMetadata(
            kind=spec.kind,
            source=spec.source,
            files=(path,),
            shape=shape,
            x_coordinate=x_name,
            y_coordinate=y_name,
            x_resolution=dx,
            y_resolution=dy,
            resolution=(dx + dy) / 2.0,
            bounds=bounds,
            crs=crs,
            unit=unit,
        )
        return _SpatialSignature(metadata, x_values, y_values)


def _find_variable(ds, spec):
    """The chosen source variable, else the exact output name or one unambiguous known source alias."""
    if spec.variable:
        if spec.variable not in ds.data_vars:
            raise ValueError(f"No variable {spec.variable!r}; the file has {list(ds.data_vars)}.")
        return spec.variable
    kind = spec.kind
    candidates = [name for name in VARIABLES[kind][0] if name in ds.data_vars
                  and ("time" in ds[name].dims or "valid_time" in ds[name].dims)]
    if kind in candidates:
        return kind
    if len(candidates) != 1:
        raise ValueError(f"Expected one source variable; found {candidates or list(ds.data_vars)}.")
    return candidates[0]


def _spatial_dims(da) -> tuple[str, str]:
    dims = [dim for dim in da.dims if dim not in {"time", "valid_time", "bnds"}]
    extra = [dim for dim in dims if da.sizes[dim] > 1]
    if len(extra) != 2:
        raise ValueError(
            f"Variable {da.name!r} must have exactly two spatial dimensions.")
    return extra[-2], extra[-1]


def _axis_values(ds, dim: str, axis: str):
    import numpy as np

    candidates = (
        ("lon", "longitude", "xc", "x", "easting")
        if axis == "x" else
        ("lat", "latitude", "yc", "y", "northing")
    )
    for name in (dim, *candidates):
        if name not in ds.variables:
            continue
        values = np.asarray(ds[name].values)
        if values.ndim == 1 and ds[name].dims == (dim,):
            return name, values
    return dim, None


def _centre_axes(ds, dims, x_name: str, y_name: str, x_values, y_values, crs):
    """Cell-centre 1-D axes. Lat/lon centres projected to `crs` place the grid, while the axes keep
    its order (lat/lon rows may be stored reversed); without them `xc`/`yc` are the left/upper edges."""
    import numpy as np

    x, y = np.asarray(x_values, dtype="float64"), np.asarray(y_values, dtype="float64")
    if x_name.lower() in {"lon", "longitude"} or x.size < 2 or y.size < 2:
        return x, y
    dx, dy = abs(float(x[1] - x[0])), abs(float(y[1] - y[0]))
    lon, lat = (_geographic_coordinate(ds, axis, dims)[1] for axis in ("lon", "lat"))
    if lon is not None and lat is not None and crs:
        from pyproj import Transformer

        lon, lat = np.asarray(lon, dtype="float64"), np.asarray(lat, dtype="float64")
        rims = (np.concatenate([grid[0], grid[-1], grid[:, 0], grid[:, -1]]) for grid in (lon, lat))
        px, py = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform(*rims)
        west, east = np.nanmin(px) - x.min(), np.nanmax(px) - x.max()
        south, north = np.nanmin(py) - y.min(), np.nanmax(py) - y.max()
        if max(abs(west), abs(east)) > dx or max(abs(south), abs(north)) > dy:
            raise ValueError(f"The lat/lon of the data do not match its {x_name}/{y_name} in {crs}; "
                             "check the meteo CRS.")
        return x + west, y + south
    if (x_name.lower(), y_name.lower()) == ("xc", "yc"):
        return x + dx / 2, y - dy / 2
    return x, y


def _geographic_coordinate(ds, axis: str, dims: tuple[str, str]):
    aliases = ("lon", "longitude") if axis == "lon" else ("lat", "latitude")
    for name in aliases:
        if name in ds.variables and ds[name].dims == dims:
            return name, ds[name].values
    return axis, None


def _dataset_crs(ds, da, x_name: str, y_name: str) -> str | None:
    if x_name.lower() in {"lon", "longitude"} and y_name.lower() in {
            "lat", "latitude"}:
        return "EPSG:4326"

    mapping_name = da.attrs.get("grid_mapping")
    candidates = [ds.attrs]
    if mapping_name and mapping_name in ds.variables:
        candidates.append(ds[mapping_name].attrs)
    for name in ("spatial_ref", "crs"):
        if name in ds.variables:
            candidates.append(ds[name].attrs)
    for attrs in candidates:
        for key in ("spatial_ref", "crs_wkt", "crs"):
            value = attrs.get(key)
            if value:
                return str(value)
    return None


def _coordinate_unit(ds, x_name: str, crs: str | None) -> str:
    units = str(ds[x_name].attrs.get("units", "")) if x_name in ds else ""
    if "degree" in units.lower() or x_name.lower() in {"lon", "longitude"}:
        return "deg"
    if crs:
        try:
            from pyproj import CRS

            return _crs_unit(CRS.from_user_input(crs))
        except (ImportError, RuntimeError):  # no pyproj, or a CRS it can't read (CRSError)
            pass
    return units or ""


def _crs_unit(crs) -> str:
    if getattr(crs, "is_geographic", False):
        return "deg"
    name = crs.axis_info[0].unit_name.lower() if crs.axis_info else ""
    if name in {"metre", "meter"}:
        return "m"
    if "foot" in name or "feet" in name:
        return "ft"
    return name


def _validate_spatial_signatures(signatures: list[_SpatialSignature]) -> None:
    import numpy as np

    first = signatures[0]
    for current in signatures[1:]:
        if current.metadata.shape != first.metadata.shape:
            raise ValueError(
                "NetCDF files do not share the same spatial dimensions: "
                f"{first.metadata.files[0].name}={first.metadata.shape}, "
                f"{current.metadata.files[0].name}={current.metadata.shape}.")
        if (
                np.shape(current.x_values) != np.shape(first.x_values)
                or np.shape(current.y_values) != np.shape(first.y_values)
                or not np.allclose(current.x_values, first.x_values,
                                   rtol=1e-9, atol=1e-9, equal_nan=True)
                or not np.allclose(current.y_values, first.y_values,
                                   rtol=1e-9, atol=1e-9, equal_nan=True)):
            raise ValueError(
                "NetCDF files do not share identical spatial coordinates: "
                f"{first.metadata.files[0].name} and "
                f"{current.metadata.files[0].name}.")
        left, right = first.metadata.crs, current.metadata.crs
        if (left is None) != (right is None) or (
                left and right and not _same_crs(left, right)):
            raise ValueError(
                "NetCDF files do not share the same CRS: "
                f"{first.metadata.files[0].name} and "
                f"{current.metadata.files[0].name}.")


def _validate_target_coverage(
        metadata: SpatialMetadata,
        target: TargetGrid) -> None:
    """Reject disjoint grids; allow padding around overlapping input."""
    import numpy as np

    target_x = np.asarray(
        target.sample_lon
        if target.sample_lon is not None else target.lon,
        dtype="float64",
    )
    target_y = np.asarray(
        target.sample_lat
        if target.sample_lat is not None else target.lat,
        dtype="float64",
    )
    if (
            target.crs
            and metadata.crs
            and _same_crs(metadata.crs, target.crs)):
        target_x, target_y = header_center_arrays(target.header)
    elif metadata.crs and not _same_crs(metadata.crs, "EPSG:4326"):
        try:
            from pyproj import Transformer
        except Exception as exc:
            raise RuntimeError(
                "pyproj is required to validate projected meteorology data.") from exc
        transform = Transformer.from_crs(
            "EPSG:4326", metadata.crs, always_xy=True)
        target_x, target_y = transform.transform(target_x, target_y)
    elif metadata.crs is None and metadata.unit not in {"deg", "degree"}:
        return

    west, east, south, north = metadata.bounds
    x_tolerance = metadata.x_resolution / 2.0 + 1e-9
    y_tolerance = metadata.y_resolution / 2.0 + 1e-9
    if (
            float(target_x.max()) < west - x_tolerance
            or float(target_x.min()) > east + x_tolerance
            or float(target_y.max()) < south - y_tolerance
            or float(target_y.min()) > north + y_tolerance):
        raise ValueError(f"The model grid is outside the {VARIABLE_LABELS.get(metadata.kind, metadata.kind).lower()} "
                         "data: check the input's extent and CRS.")


def validate_coverage(metadata: SpatialMetadata, bounds, crs, l0_resolution=0.0) -> None:
    """The source's cell edges must contain the study `bounds` (xmin, xmax, ymin, ymax in `crs`), less
    1% of an L0 cell for coordinate rounding (lat/lon stored as float32)."""
    margin = 0.01 * float(l0_resolution)
    xmin, xmax, ymin, ymax = (float(value) + sign * margin for value, sign in zip(bounds, (1, -1, 1, -1), strict=True))
    source_crs = metadata.crs or ("EPSG:4326" if metadata.unit in {"deg", "degree"} else None)
    if not source_crs:
        return
    if crs and not _same_crs(source_crs, crs):
        from pyproj import Transformer
        xmin, ymin, xmax, ymax = Transformer.from_crs(crs, source_crs, always_xy=True).transform_bounds(
            xmin, ymin, xmax, ymax, densify_pts=21)
    west, east, south, north = metadata.bounds  # cell centres
    half_x, half_y = metadata.x_resolution / 2, metadata.y_resolution / 2
    tolerance = max(metadata.x_resolution, metadata.y_resolution) * 1e-6
    edges = (west - half_x, east + half_x, south - half_y, north + half_y)
    if (xmin < edges[0] - tolerance or xmax > edges[1] + tolerance
            or ymin < edges[2] - tolerance or ymax > edges[3] + tolerance):
        raise ValueError(
            f"The {VARIABLE_LABELS.get(metadata.kind, metadata.kind).lower()} data "
            f"({', '.join(f'{value:.10g}' for value in edges)}) do not cover the study extent "
            f"({xmin:.10g}, {xmax:.10g}, {ymin:.10g}, {ymax:.10g}): use inputs that cover the whole domain.")



def grid_note(metadata: SpatialMetadata, grid, crs, level="L2") -> str:
    """How an inspected input reaches the common `level` grid (`grid`, the saved grid metadata), as
    `_resample_ready` will do it: copied, shifted onto the lattice, or resampled (nearest).
    ValueError when it does not cover the common extent."""
    validate_coverage(metadata, grid["study_bounds"], crs, grid.get("l0_resolution", 0.0))
    header, source_crs = grid[f"{level.lower()}_header"], metadata.crs or ("EPSG:4326" if metadata.unit in {"deg", "degree"} else None)
    cell = float(header["cellsize"])
    if source_crs and crs and _same_crs(source_crs, crs) and all(
            math.isclose(value, cell, rel_tol=1e-6) for value in (metadata.x_resolution, metadata.y_resolution)):
        offsets = []
        for centre, corner in ((metadata.bounds[0], header["xllcorner"]), (metadata.bounds[2], header["yllcorner"])):
            steps = (centre - float(corner)) / cell - 0.5
            offsets.append((round(steps) - steps) * cell)
        if all(abs(value) <= 1e-6 * cell for value in offsets):
            return f"Covers the common extent; already on the {level} grid: copied."
        return (f"Covers the common extent; shifted by ({offsets[0]:.6g}, {offsets[1]:.6g}) onto the {level} grid "
                "(nearest cells), not resampled.")
    return (f"Covers the common extent; resampled (nearest) from {metadata.x_resolution:.6g} {metadata.unit} "
            f"({source_crs or 'no CRS'}) to the {level} grid ({cell:.6g}).")

def _resample_ready(da, ds, source_crs, target, np, xr):
    y_dim, x_dim = _spatial_dims(da)
    x_name, x_values = _axis_values(ds, x_dim, "x")
    y_name, y_values = _axis_values(ds, y_dim, "y")
    target_lon = np.asarray(target.lon, dtype="float64")
    target_lat = np.asarray(target.lat, dtype="float64")
    sample_lon = (
        np.asarray(target.sample_lon, dtype="float64")
        if target.sample_lon is not None else None
    )
    sample_lat = (
        np.asarray(target.sample_lat, dtype="float64")
        if target.sample_lat is not None else None
    )

    if x_values is not None and y_values is not None:
        source_crs = _dataset_crs(ds, da, x_name, y_name) or source_crs
        _lon_name, lon = _geographic_coordinate(ds, "lon", (y_dim, x_dim))
        _lat_name, lat = _geographic_coordinate(ds, "lat", (y_dim, x_dim))
        if source_crs is None and lon is not None and lat is not None:
            return nearest_curvilinear(
                da, np.asarray(lon), np.asarray(lat),
                target_lon, target_lat, sample_lon, sample_lat)
        x_values, y_values = _centre_axes(ds, (y_dim, x_dim), x_name, y_name, x_values, y_values, source_crs)
        x_target, y_target = target_lon, target_lat
        target_crs_matches = bool(
            source_crs and target.crs and _same_crs(source_crs, target.crs)
        )
        if target_crs_matches:
            x_target, y_target = header_center_arrays(target.header)
        elif sample_lon is not None:
            x_target, y_target = sample_lon, sample_lat
            if source_crs and not _same_crs(source_crs, "EPSG:4326"):
                try:
                    from pyproj import Transformer
                except Exception as exc:
                    raise RuntimeError(
                        "pyproj is required to resample projected "
                        "mHM-ready data."
                    ) from exc
                transform = Transformer.from_crs(
                    "EPSG:4326",
                    source_crs,
                    always_xy=True,
                )
                x_target, y_target = transform.transform(
                    x_target,
                    y_target,
                )
            return nearest_rectilinear(
                da,
                np.asarray(x_values),
                np.asarray(y_values),
                x_target,
                y_target,
                target_lon,
                target_lat,
            )
        elif source_crs and not _same_crs(source_crs, "EPSG:4326"):
            try:
                from pyproj import Transformer
            except Exception as exc:
                raise RuntimeError(
                    "pyproj is required to resample projected mHM-ready data.") from exc
            transform = Transformer.from_crs(
                "EPSG:4326", source_crs, always_xy=True)
            center_lat = float((target_lat.min() + target_lat.max()) / 2.0)
            center_lon = float((target_lon.min() + target_lon.max()) / 2.0)
            x_target = np.asarray([
                transform.transform(lon, center_lat)[0]
                for lon in target_lon])
            y_target = np.asarray([
                transform.transform(center_lon, lat)[1]
                for lat in target_lat])

        if target_crs_matches:
            x_values, y_values = shift_onto_header(x_values, y_values, target.header)
        source = da.assign_coords(
            {x_dim: np.asarray(x_values), y_dim: np.asarray(y_values)})
        source = source.sortby(x_dim).sortby(y_dim)
        if target_crs_matches and axes_match_header(
                x_values, y_values, target.header):
            result = slice_and_pad(source, x_dim, y_dim, target.header)
        else:
            result = source.interp(
                {x_dim: x_target, y_dim: y_target}, method="nearest")
        result = result.reset_coords(drop=True).rename(  # the source lat/lon go: the target ones follow
            {x_dim: "lon", y_dim: "lat"})
        return result.assign_coords(lon=target_lon, lat=target_lat).transpose(
            "time", "lat", "lon")

    _lon_name, lon = _geographic_coordinate(ds, "lon", (y_dim, x_dim))
    _lat_name, lat = _geographic_coordinate(ds, "lat", (y_dim, x_dim))
    if lon is None or lat is None:
        raise ValueError("mHM-ready data has no usable spatial coordinates.")
    return nearest_curvilinear(
        da,
        np.asarray(lon),
        np.asarray(lat),
        target_lon,
        target_lat,
        sample_lon,
        sample_lat,
    )


def _attach_target_coordinates(ds, variable: str, target: TargetGrid):
    """Attach exact 2-D cell-centre coordinates for projected target grids."""
    if target.sample_lon is None or target.sample_lat is None:
        return ds

    ds = ds.assign_coords({
        "lon2d": (
            ("lat", "lon"),
            target.sample_lon,
            {
                "standard_name": "longitude",
                "units": "degrees_east",
            },
        ),
        "lat2d": (
            ("lat", "lon"),
            target.sample_lat,
            {
                "standard_name": "latitude",
                "units": "degrees_north",
            },
        ),
    })
    ds["lon"].attrs = {"standard_name": "projection_x_coordinate", "axis": "X"}
    ds["lat"].attrs = {"standard_name": "projection_y_coordinate", "axis": "Y"}
    ds[variable].encoding.pop("coordinates", None)
    ds[variable].attrs["coordinates"] = "lat2d lon2d"
    described = _crs_description(target.crs)
    if described is not None:
        unit, crs_attrs = described
        ds["lon"].attrs["units"] = ds["lat"].attrs["units"] = unit
        ds["crs"] = 0
        ds["crs"].attrs.update(crs_attrs)
        ds[variable].attrs["grid_mapping"] = "crs"
    return ds


@lru_cache(maxsize=8)
def _crs_description(crs_text: str):
    """Return (axis unit, CF grid-mapping attributes) for one CRS, once.

    This is constant for a whole run but used to be rebuilt for every written
    block, which on a multi-decade hourly record meant tens of thousands of
    pyproj calls from a Qt worker thread.
    """
    if not crs_text:
        return None
    try:
        from pyproj import CRS

        crs = CRS.from_user_input(crs_text)
        attrs = dict(crs.to_cf())
        attrs["spatial_ref"] = crs.to_wkt()
        return (crs.axis_info[0].unit_name if crs.axis_info else "metre"), attrs
    except Exception:
        return None
