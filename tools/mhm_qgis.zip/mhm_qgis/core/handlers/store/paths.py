"""Where things live: pure path construction, no I/O and no version branching.

Deliberately the leaf of the store. `core/handlers/state` imports only this, so
the arrow between state and store never reverses -- a version-aware path helper
here would have to read the input state, and the state modules need
`workspace_folder` to find that file in the first place.
"""
from __future__ import annotations

import os
from pathlib import Path

#: The plugin owns these directories inside a user's project: single-domain
#: setups, and multi-domain setups that combine them.
WORKSPACE_FOLDER_NAME = "mhm-qgis"
MULTI_FOLDER_NAME = "mhm-qgis-multi"


def plugin_root() -> str:
    """Return the plugin package root.

    This module sits three levels inside the package, so the root is three
    directories up -- not this file's own directory.
    """
    here = os.path.dirname(os.path.abspath(__file__))       # .../core/handlers/store
    return os.path.dirname(os.path.dirname(os.path.dirname(here)))


def settings_path(setup_folder) -> str:
    """Return editable settings in the selected setup root."""
    return os.path.join(str(setup_folder), "settings.yaml")


def workspace_folder(setup_folder) -> str:
    """Return the domain folder that owns every plugin file of one setup."""
    return str(setup_folder)


def domain_folder(project_directory, name, workspace=WORKSPACE_FOLDER_NAME) -> Path:
    """Resolve a safe, non-symlink setup name without creating anything."""
    name = str(name).strip()
    reserved = {"data", "output", "restart", "<new>"}
    if (not name or name in {".", ".."} or name.casefold() in reserved
            or name.startswith(".") or any(c in name for c in '/\\\0<>:"|?*')
            or name.endswith((".", " "))):
        raise ValueError("Enter a domain folder name without path separators or reserved characters.")
    path = Path(project_directory) / workspace / name
    if path.is_symlink() or (path.exists() and not path.is_dir()):
        raise ValueError("The domain must be a real directory, not a file or symlink.")
    return path


def version_key(version_text: str | None) -> str:
    """Return the normalized version folder name used by templates."""
    text = (version_text or "").strip().lower().removeprefix("v")
    return "v6" if text.startswith("6") else "v5.13"


def schemas_folder(version_text: str | None) -> Path:
    """Return the packaged nml-tools schema folder for an mHM version."""
    return Path(plugin_root()) / "nml-schemas" / version_key(version_text)


def namelist_project(version_text: str | None, combined: bool = False) -> str:
    """The nml-tools project profile of a setup (`nml-config.toml` `project_profiles`):
    `v5` for v5.13, `combine` for a v6 multi-domain setup, `classic` otherwise."""
    if version_key(version_text) == "v5.13":
        return "v5"
    return "combine" if combined else "classic"


def temp_folder(setup_folder) -> str:
    """Return the hidden folder for temporary artifacts and plugin state."""
    return os.path.join(workspace_folder(setup_folder), ".temp")


def temp_morphology_folder(setup_folder) -> str:
    """Return the temporary morphology workspace, which also stages morph and LAI."""
    return os.path.join(temp_folder(setup_folder), "Morphology")


def morph_staging_folder(setup_folder) -> str:
    """Return the staging folder for land cover, soil, and geology outputs.

    Execute All stages here before its final publication to data.
    """
    return os.path.join(temp_morphology_folder(setup_folder), "morph")


def lai_staging_folder(setup_folder) -> str:
    """Return the staging folder for common-grid LAI."""
    return os.path.join(temp_morphology_folder(setup_folder), "lai")


def lai_dem_staging_path(setup_folder) -> str:
    """Return the staged LAI resampled onto the filled DEM grid."""
    return os.path.join(lai_staging_folder(setup_folder), "lai_dem.nc")


def data_folder(setup_folder) -> str:
    """Return the mHM data folder."""
    return os.path.join(workspace_folder(setup_folder), "data")


def static_folder(setup_folder) -> str:
    """Return the shared static data folder."""
    return os.path.join(data_folder(setup_folder), "static")


def meteo_folder(setup_folder) -> str:
    """Return the meteorology forcing data folder."""
    return os.path.join(data_folder(setup_folder), "meteo")


def output_folder(setup_folder) -> str:
    """Return the mHM output folder."""
    return os.path.join(workspace_folder(setup_folder), "output")


def restart_folder(setup_folder) -> str:
    """Return the mHM restart folder."""
    return os.path.join(workspace_folder(setup_folder), "restart")
