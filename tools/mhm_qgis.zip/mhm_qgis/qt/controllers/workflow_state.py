"""Persist workflow state, reflect it on main-form buttons, and guard actions on it."""

from qgis.PyQt.QtWidgets import QMessageBox

from ...core import verify
from ...core.handlers.state import processing
from .. import project_tree

# The `core.verify` stages a finished ▶ prepared the files for
VERIFY = {"execute_all_morphology": ("morphology", "gauges"), "execute_all_meteo": ("meteo",)}


def report(dialog, *stages):
    """Log and show what mHM would stop on in `stages` of the saved setup."""
    try:
        problems = [problem for stage in stages for problem in verify.check(dialog.setup_folder, stage)]
    except (OSError, ValueError, KeyError, TypeError) as error:
        dialog.log_message(f"WARNING: Could not check the inputs against mHM: {error}")
        return
    for problem in problems:
        dialog.log_message(f"ERROR: {problem}")
    if problems and not dialog._closing:
        QMessageBox.warning(dialog, "mHM input check", "mHM would stop on:\n\n" + "\n".join(problems[:10]))


def set_status(dialog, key, status, message=""):
    if dialog.setup_folder:
        processing.mark_workflow(dialog.setup_folder, key, status, message)
    set_button_state(dialog, key, status)


def invalidate(dialog, *keys):
    if dialog._loading_input_state or not dialog.setup_folder:
        return
    for key in keys:
        processing.mark_workflow(dialog.setup_folder, key, "pending")
        set_button_state(dialog, key, "")


def specs(dialog):
    return {
        "project_structure": {
            "button": dialog.pushButton_createOrLoadDomainStructure,
            "label": "Project Structure",
            "completed_message": "Project structure is ready.",
            "failed_message": "Project structure setup failed.",
        },
        "execute_all_morphology": {
            "button": project_tree.button(dialog, "morphology"),
            "label": "Execute All Morphology",
            "completed_message": "Morphology preparation completed successfully.",
            "failed_message": "Execute All Morphology failed. Check the log for details.",
        },
        "execute_all_meteo": {
            "button": project_tree.button(dialog, "meteorology"),
            "label": "Meteorology Preparation",
            "completed_message": "Meteorology preparation completed successfully.",
            "failed_message": "Meteorology preparation failed. Check the log for details.",
        },
        "execute_all_observations": {
            "button": project_tree.button(dialog, "observations"),
            "label": "Observation Preparation",
            "completed_message": "Observation preparation completed.",
            "failed_message": "Observation preparation failed.",
        },
        "run_mhm": {
            "button": dialog.pushButton_execute_mHM,
            "label": "Run mHM",
            "completed_message": "mHM completed successfully.",
            "failed_message": "mHM execution failed.",
        },
    }


def button(dialog, workflow_key):
    return specs(dialog).get(workflow_key, {}).get("button")


def running_key(dialog):
    """Return the Execute workflow in progress (a running mHM is "run_mhm"), or None; at most one runs."""
    terminal = getattr(dialog, "_terminal_dialog", None)
    return dialog._running_workflow or ("run_mhm" if terminal is not None and terminal.command_running() else None)


def begin(dialog, workflow_key):
    """Mark `workflow_key` as the running workflow and lock the setup controls."""
    dialog._running_workflow = workflow_key
    set_status(dialog, workflow_key, "running")
    set_setup_controls_enabled(dialog, False)


def capture_button_styles(dialog):
    for workflow_key, spec in specs(dialog).items():
        control = spec["button"]
        dialog._workflow_button_default_styles[workflow_key] = control.styleSheet()
        # a bordered style sheet drops the native padding: keep the native size as the minimum
        control.setMinimumSize(control.sizeHint().boundedTo(control.maximumSize()))


def set_setup_controls_enabled(dialog, enabled):
    """Lock the inputs a running workflow reads, so they cannot change under it."""
    for widget in (
        dialog.page_projectSetup,
        dialog.tabWidget_steps,
    ):
        widget.setEnabled(enabled)


def set_button_state(dialog, workflow_key, status):
    control = button(dialog, workflow_key)
    if control is None:
        return
    control.setEnabled(status != "running")
    if status in ("running", "completed", "failed"):
        color, border = {"running": ("#f6c453", "#a66f00"), "completed": ("#a5d6a7", "#66bb6a"),
                         "failed": ("#c62828", "#8e0000")}[status]
        control.setStyleSheet(
            "QPushButton {"
            f"background-color: {color};"
            f"border: 1px solid {border};"
            "border-radius: 3px;"
            "}"
        )
    else:
        control.setStyleSheet(dialog._workflow_button_default_styles.get(workflow_key, ""))
    if status != "running" and workflow_key in ("execute_all_morphology", "execute_all_meteo", "execute_all_observations"):
        from . import process_cases

        process_cases.inputs(dialog)  # re-check the prepared files: the statuses and ▶ follow them


def refresh_all(dialog):
    for workflow_key in specs(dialog):
        refresh(dialog, workflow_key)


def refresh(dialog, workflow_key):
    if running_key(dialog) == workflow_key:
        return
    status = processing.workflow(dialog.setup_folder, workflow_key).get("status")
    set_button_state(
        dialog,
        workflow_key,
        status if status in {"completed", "failed"} else "",
    )


def finish(dialog, workflow_key, ok, message):
    """Record the outcome of the running workflow, unlock, and tell the user.

    Only the first outcome counts: a stage pipeline may report more than one.
    """
    if dialog._running_workflow != workflow_key:
        return
    dialog._running_workflow = None
    set_setup_controls_enabled(dialog, True)
    workflow = specs(dialog)[workflow_key]
    if ok:
        try:
            completed = workflow["completed_message"]
            processing.mark_workflow(dialog.setup_folder, workflow_key, "completed", completed)
            set_button_state(dialog, workflow_key, "completed")
            dialog.log_message(completed)
            report(dialog, *VERIFY.get(workflow_key, ()))
            return
        except Exception as error:  # An unrecordable success is a failure.
            message = str(error)
    message = (
        message
        or processing.workflow(dialog.setup_folder, workflow_key).get("message")
        or workflow["failed_message"]
    )
    processing.mark_workflow(dialog.setup_folder, workflow_key, "failed", message)
    set_button_state(dialog, workflow_key, "failed")
    dialog.log_message(message)
    if not dialog._closing:
        QMessageBox.critical(dialog, workflow["label"], message)


def invalidate_meteo(dialog):
    if (
        dialog._loading_input_state
        or not dialog.setup_folder
        or running_key(dialog) == "execute_all_meteo"
    ):
        return
    for key in ("execute_all_meteo", "run_mhm"):
        processing.remove_entry(dialog.setup_folder, "workflows", key)
        set_button_state(dialog, key, "")


def switch_busy(dialog):
    terminal = dialog._terminal_dialog
    if (
        dialog.task_coordinator.is_busy()
        or running_key(dialog)
        or (terminal is not None and terminal.command_running())
    ):
        QMessageBox.warning(
            dialog,
            "Domain selection",
            "Finish or cancel running tasks before switching domains.",
        )
        return True
    return False


def require_active(dialog) -> bool:
    if dialog.setup_folder:
        return True
    QMessageBox.warning(
        dialog,
        "Project Folder Required",
        "Select a project folder before editing namelists.",
    )
    return False
