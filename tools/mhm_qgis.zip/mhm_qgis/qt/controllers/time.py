"""Simulation-time widgets and their namelist state."""

from qgis.PyQt.QtCore import QDateTime, QSignalBlocker

from .version import selected as selected_version

TIME_WIDGETS = {
    "sim_start": "dateTimeEdit_simulationStartTimeInput",
    "eval_start": "dateTimeEdit_evaluationStartTimeInput",
    "sim_end": "dateTimeEdit_simulationEndTimeInput",
}


def _widget_values(dialog):
    return {
        key: getattr(dialog, name).dateTime().toString("yyyy-MM-ddTHH:mm")
        for key, name in TIME_WIDGETS.items()
    }


def values(dialog):
    from ...core.handlers.state.nml_settings import validate_times

    return validate_times(_widget_values(dialog), selected_version(dialog))


def save(dialog):
    if dialog._loading_input_state or not dialog.setup_folder:
        return
    from ...core.handlers.state.nml_settings import update_section

    result = _widget_values(dialog)
    update_section(dialog.setup_folder, "time", result)
    from ...core.executions.meteo import covers_period
    from .workflow_state import invalidate, invalidate_meteo

    if covers_period(dialog.setup_folder, result):
        invalidate(dialog, "run_mhm")
    else:
        invalidate_meteo(dialog)
    show_period(dialog)



def set_period(dialog):
    """Set Periods on the Precipitation page: the checked simulation period, into nml-settings.json."""
    from qgis.PyQt.QtWidgets import QMessageBox

    try:
        values(dialog)
    except ValueError as error:
        QMessageBox.warning(dialog, "Simulation period", str(error))
        return
    save(dialog)
    dialog.save_input_state()  # Precipitation's status: a saved period completes it
    from .workflow_state import report

    report(dialog, "period")


def show_period(dialog):
    """The plugin's time toolbar on the simulation period, a step a day, unless a run's outputs hold it.

    Without QGIS Desktop the toolbar lives in the map window, so it is only updated once it exists.
    """
    if dialog._post.intervals is not None or (dialog.iface is None and dialog._post.toolbar is None):
        return
    import numpy as np

    from . import post_context

    period = _widget_values(dialog)
    days = np.arange(np.datetime64(period["sim_start"][:10]), np.datetime64(period["sim_end"][:10]) + 1)
    if len(days):
        post_context.time_axis(dialog, np.column_stack([days, days]), lambda _index: None)


def restore(dialog):
    from ...core.handlers.state.nml_settings import load_settings

    saved = (
        load_settings(dialog.setup_folder).get("time", {})
        if dialog.setup_folder
        else {}
    )
    for key, name in TIME_WIDGETS.items():
        widget = getattr(dialog, name)
        value = QDateTime.fromString(
            saved.get(key, "2000-01-01T00:00"), "yyyy-MM-ddTHH:mm"
        )
        if value.isValid():
            with QSignalBlocker(widget):
                widget.setDateTime(value)
    if saved:
        show_period(dialog)
