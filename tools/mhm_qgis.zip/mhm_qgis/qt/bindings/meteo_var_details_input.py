"""Fixed wiring for the meteorology details form."""
from ..controllers import meteo_var_details_input as controller


def bind(dialog):
    """Connect the browser and resolution controls."""
    # pushButton_browseMeteoNetcdfFile → controller.browse
    dialog.pushButton_browseMeteoNetcdfFile.clicked.connect(lambda: controller.browse(dialog))
    dialog.pushButton_scanFiles.clicked.connect(lambda: controller.scan_files(dialog))
    dialog.comboBox_temporalResolutionInput.currentTextChanged.connect(
        lambda: controller.populate_output_resolutions(dialog))
    dialog.comboBox_temporalResolutionInput.currentTextChanged.connect(lambda: controller.populate_resets(dialog))
    dialog.comboBox_resetInterval.currentTextChanged.connect(lambda: controller.populate_reset_timestamps(dialog))
    dialog.comboBox_temporalResolutionOutput.currentTextChanged.connect(
        lambda: controller.update_aggregation_control(dialog))
